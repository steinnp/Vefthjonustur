'use strict';
const Users = require('./Users');
const Punches = require('./Punches');
const Companies = require('./Companies');

module.exports = {
  Users,
  Punches,
  Companies,
};
