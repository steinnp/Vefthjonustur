using System;

namespace WebApplication.Models
{
  public class Student
  {
      public string SSN { get; set; }
      public string Name { get; set; }
  }
}