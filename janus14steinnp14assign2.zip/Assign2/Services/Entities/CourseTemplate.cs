using System;
namespace Assign2.Services.Entities
{
    public class CourseTemplate
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string CourseID { get; set; }
    }
}
