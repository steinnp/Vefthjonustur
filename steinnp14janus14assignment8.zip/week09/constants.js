'use strict';
const port = 4730;
module.exports = {
  ADMIN_TOKEN: 'smuuu',
  SERVER_URL: `localhost${port}`,
  SERVER_PORT: port,
  DATABASE_URL: 'mongodb://localhost:27017/app',
};
