namespace Assign3.Services.Entities
{
    public class CourseStudent
    {
        public string CourseID { get; set; }
        public string SSN { get; set; }
    }
}