namespace Assign3.Services.Entities
{
    public class StudentLinker
    {
        public int ID { get; set; }
        public int CourseID { get; set; }
        public string StudentID { get; set; }
        public int IsActive { get; set; }
    }
}