namespace Assign3.Services.Entities
{
    public class WaitingList
    {
        public int ID { get; set; }
        public int CourseID { get; set; }
        public string StudentID { get; set; }
    }
}