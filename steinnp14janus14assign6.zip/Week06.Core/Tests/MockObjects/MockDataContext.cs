﻿namespace CoursesAPI.Tests.MockObjects
{
	public class MockDataContext
	{
	}
}
